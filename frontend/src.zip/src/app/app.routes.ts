import { authGuard } from './core/guards/auth.guard';
import { ActivatedRouteSnapshot, Routes } from '@angular/router';
import { AdminGuard } from './core/guards/admin.guard';

export const routes: Routes = [
  {
    path: 'account',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/account/account.component').then(
        (m) => m.AccountComponent,
      ),
  },
  {
    path: 'meus-pedidos',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/order-history/order-history.component').then(
        (m) => m.OrderHistoryComponent,
      ),
  },
  {
    path: 'meus-pedidos/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/order-history/order-history.component').then(
        (m) => m.OrderHistoryComponent,
      ),
  },
  {
    path: 'checkout/success/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/checkout/checkout-success/checkout-success.component').then(
        (m) => m.CheckoutSuccessComponent,
      ),
  },
  {
    path: 'checkout',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/checkout/checkout.component').then(
        (m) => m.CheckoutComponent,
      ),
  },
  {
    path: 'favorites',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/favorites/favorites.component').then(
        (m) => m.FavoritesComponent,
      ),
  },
  {
    path: 'cart',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/cart/cart.component').then((m) => m.CartComponent),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },

  {
    path: 'home',
    loadComponent: () =>
      import('./features/home/home.component').then((m) => m.HomeComponent),
  },

  {
    path: 'campanha/:id',
    loadComponent: () => import('./features/campaign/campaign.component').then(m=>m.CampaignComponent),
  },
  {
    path: 'categoria/:slug',
    loadComponent: () =>
      import('./features/catalog/pages/category/category.component').then(
        (m) => m.CategoryComponent,
      ),
  },

  {
    path: 'produto/:slug',
    loadComponent: () =>
      import('./features/catalog/pages/product-detail/product-detail.component').then(
        (m) => m.ProductDetailComponent,
      ),
  },

  {
    // One route configuration preserves the auth panel and video between tabs.
    matcher: (segments) =>
      segments.length === 1 && ['login', 'register'].includes(segments[0].path)
        ? { consumed: segments, posParams: { authPage: segments[0] } }
        : null,
    resolve: {
      selectedTab: (route: ActivatedRouteSnapshot) =>
        route.paramMap.get('authPage') === 'register' ? 1 : 0,
    },
    loadComponent: () =>
      import('./features/authorization/register/register.component').then(
        (m) => m.AuthComponent,
      ),
  },

  {
    path: 'forgot-password',
    data: { recoveryStep: 'email' },
    loadComponent: () =>
      import('./shared/forgot-password/forgot-password.component').then(
        ({ ForgotPasswordComponent }) => ForgotPasswordComponent,
      ),
  },

  {
    path: 'verify-code',
    data: { recoveryStep: 'otp' },
    loadComponent: () =>
      import('./shared/forgot-password/forgot-password.component').then(
        ({ ForgotPasswordComponent }) => ForgotPasswordComponent,
      ),
  },

  {
    path: 'reset-password',
    loadComponent: () =>
      import('./shared/reset-password/reset-password.component').then(
        (m) => m.ResetPasswordComponent,
      ),
  },

  {
    path: 'image-upload/:id',
    canMatch: [AdminGuard],
    loadComponent: () =>
      import('./features/product-manage/images/product-image-upload/product-image-upload.component').then(
        (m) => m.ProductImageUploadComponent,
      ),
  },

  {
    path: 'product-register',
    canDeactivate: [(page: import('./features/product-manage/register/product-create/product-create.component').ProductCreateComponent) => page.canLeave()],
    canMatch: [AdminGuard],
    loadComponent: () =>
      import('./features/product-manage/register/product-create/product-create.component').then(
        (m) => m.ProductCreateComponent,
      ),
  },

  { path: 'promotion-register', pathMatch: 'full', redirectTo: 'admin/promotions/new' },
  { path: 'add-to-promotion', pathMatch: 'full', redirectTo: 'admin/promotions' },

  {
    path: 'admin',
    canMatch: [AdminGuard],
    loadChildren: () =>
      import('./components/admin/admin.module').then((m) => m.AdminModule),
  },

  {
    path: '404',
    loadComponent: () =>
      import('./features/not-found/not-found.component').then(
        (m) => m.NotFoundComponent,
      ),
  },

  {
    path: '**',
    loadComponent: () =>
      import('./features/not-found/not-found.component').then(
        (m) => m.NotFoundComponent,
      ),
  },
];
