import type { ProductUpdateRequest, ProductImageRecord, ProductCommerceUpdate } from '../../shared/types/products/admin-product';
export type { ProductUpdateRequest, ProductImageRecord } from '../../shared/types/products/admin-product';
import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Product } from '../../shared/models';
import { forkJoin, Observable } from 'rxjs';
import { Page, PageOptions, PaginationService } from './pagination.service';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private readonly pagination = inject(PaginationService);
  private apiUrl = 'http://localhost:8080/products';

  constructor(private http: HttpClient) {}

  createCatalogRegistration(kind: 'categories' | 'brands', name: string) {
    return this.http.post<{ id: number; name: string }>('http://localhost:8080/admin/catalog/' + kind, { name });
  }

  getBrands(): Observable<{ id: number; name: string }[]> {
    return this.http.get<{ id: number; name: string }[]>('http://localhost:8080/admin/products/brands');
  }

  getProductTypes(): Observable<{ id: number; name: string }[]> {
    return this.http.get<{ id: number; name: string }[]>(this.apiUrl + "/categories");
  }

  getProducts(filters?: PageOptions['filters']): Observable<Product[]> {
    return this.pagination.getAll<Product>(this.apiUrl, filters);
  }

  getProductsPage(options: PageOptions = {}): Observable<Page<Product>> {
    return this.pagination.getPage<Product>(this.apiUrl, options);
  }

  getAdminProducts(): Observable<Product[]> {
    return this.pagination.getAll<Product>('http://localhost:8080/admin/products');
  }
  getAdminProductsPage(options: PageOptions = {}): Observable<Page<Product>> {
    return this.pagination.getPage<Product>(
      'http://localhost:8080/admin/products',
      options,
    );
  }

  createProduct(product: Product): Observable<{ id: number }> {
    return this.http.post<{ id: number }>(this.apiUrl, product);
  }

  getAdminProduct(id:number){return this.http.get<Product>(`http://localhost:8080/admin/products/${id}`);}
  updateProduct(id:number,request:ProductUpdateRequest){return this.http.patch<Product>(`http://localhost:8080/admin/products/${id}`,request);}
  removeProduct(id:number){return this.http.delete<{action:'deleted'|'archived'}>(`http://localhost:8080/admin/products/${id}`);}
  getProductImages(id:number){return this.http.get<ProductImageRecord[]>(`http://localhost:8080/admin/products/${id}/images`);}
  orderProductImages(id:number,variant_id:number|null,ids:number[],expected_ids:number[],primary_id:number){return this.http.put<ProductImageRecord[]>(`http://localhost:8080/admin/products/${id}/images`,{variant_id,ids,expected_ids,primary_id});}
  removeProductImage(id:number,imageId:number){return this.http.delete<ProductImageRecord[]>(`http://localhost:8080/admin/products/${id}/images/${imageId}`);}

  saveVariants(id:number,variants:NonNullable<Product['variants']>,expected:NonNullable<Product['variants']>,commerce?:ProductCommerceUpdate) {
    return this.http.put<{variants:NonNullable<Product['variants']>}>(`http://localhost:8080/admin/products/${id}/variants`,{variants,expected_variants:expected,...(commerce ? {commerce} : {})});
  }

  getProduct(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  getRelatedProducts(id: number): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/${id}/related`);
  }

  getProductsByIds(ids: number[]): Observable<Product[]> {
    const requests = ids.map((id) => this.getProduct(id));
    return forkJoin(requests);
  }
}

