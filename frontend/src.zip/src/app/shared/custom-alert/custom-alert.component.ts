import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnDestroy,
  ViewEncapsulation,
} from '@angular/core';
import { AlertType } from '../../shared/models';

@Component({
  selector: 'app-custom-alert',
  standalone: true,
  templateUrl: './custom-alert.component.html',
  styleUrls: ['./custom-alert.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CustomAlertComponent implements OnInit, OnDestroy {
  @Input() title: string = '';
  @Input() message: string = '';
  @Input() type: AlertType = 'info';
  @Input() duration: number = 2000;
  @Input() showClose: boolean = true;
  @Input() showProgress: boolean = true;

  @Input() action?: { label: string; run: () => void };
  readonly icons: Record<AlertType, string> = {
    success: 'check',
    error: 'error_outline',
    warning: 'warning_amber',
    info: 'info_outline',
    loading: 'autorenew',
  };

  activate(): void {
    if (this.closing) return;
    this.action?.run();
    this.close();
  }

  @Input() recoverySuccess = false;
  @Output() elapsed = new EventEmitter<void>();

  @Output() closed = new EventEmitter<void>();

  visible: boolean = false;
  private timeoutId?: ReturnType<typeof setTimeout>;
  private exitTimeoutId?: ReturnType<typeof setTimeout>;
  private closing = false;

  ngOnInit() {
    this.visible = true;

    if (this.duration > 0) {
      this.timeoutId = setTimeout(() => {
        this.elapsed.emit();
        this.close();
      }, this.duration);
    }
  }

  ngOnDestroy() {
    clearTimeout(this.exitTimeoutId);
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  onClose() {
    this.close();
  }

  private close() {
    if (this.closing) return;
    this.closing = true;
    clearTimeout(this.timeoutId);
    this.visible = false;
    this.exitTimeoutId = setTimeout(() => {
      this.closed.emit();
    }, 90);
  }
}
