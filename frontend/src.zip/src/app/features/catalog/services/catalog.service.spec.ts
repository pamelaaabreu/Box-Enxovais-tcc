import { TestBed } from '@angular/core/testing';
import { firstValueFrom, of } from 'rxjs';
import { CatalogService } from './catalog.service';
import { ProductService } from '../../../core/services/product.service';

describe('CatalogService API mapping',()=>{
 it('resolves a database category and lists its products by ID', async () => {
  const getProductsPage = jasmine.createSpy('getProductsPage').and.returnValue(of({items: []}));
  TestBed.configureTestingModule({providers:[{provide:ProductService,useValue:{
    getProductTypes: () => of([{id: 81, name: 'Toalhas'}, {id: 82, name: 'Roupa de banho'}]),
    getProductsPage,
  }}]});
  const service = TestBed.inject(CatalogService);
  const category = await firstValueFrom(service.getCategoryBySlug('toalhas'));
  expect(category).toEqual(jasmine.objectContaining({id: 81, name: 'Toalhas'}));
  const product = service.adapt({id: 10, name: 'Roupão', category_name: 'Roupa de banho', product_type_id: 82} as Parameters<CatalogService['adapt']>[0]);
  expect(await firstValueFrom(service.getCategoryBySlug(product.category.slug))).toEqual(product.category);
  await firstValueFrom(service.getCategoryPage(category!, {limit: 12}));
  expect(getProductsPage).toHaveBeenCalledWith({limit: 12, filters: {product_type_id: 81}});
  expect(await firstValueFrom(service.getCategoryBySlug('inexistente'))).toBeNull();
 });

 it('resolves Cama to exact group members and keeps the catalog filters', async () => {
  const getProductsPage = jasmine.createSpy('getProductsPage').and.returnValue(of({ items: [] }));
  TestBed.configureTestingModule({ providers: [{ provide: ProductService, useValue: {
    getProductTypes: () => of([
      { id: 90, name: 'Cama / Edredons' },
      { id: 32, name: 'Cama / Jogos de cama' },
      { id: 13, name: 'Cama / Outro' },
    ]),
    getProductsPage,
  } }] });
  const service = TestBed.inject(CatalogService);
  const group = (await firstValueFrom(service.getCategoryBySlug('cama')))!;
  expect(group.children?.map(child => child.id)).toEqual([32, 90]);
  await firstValueFrom(service.getCategoryPage(group, { limit: 12, filters: { sort: 'name' } }));
  expect(getProductsPage).toHaveBeenCalledWith({ limit: 12, filters: { product_type_ids: '32,90', sort: 'name' } });
  const empty = await firstValueFrom(service.getCategoryPage({ ...group, children: [] }, {}));
  expect(empty.pagination.total).toBe(0);
  expect(getProductsPage).toHaveBeenCalledTimes(1);
 });

 it('uses real IDs, category names and stock without mock variants',async()=>{
  const product={id:42,name:'Jogo de cama',category_name:'Cama',status:'active',price:129.9,quantity:4,image_paths:[]};
  TestBed.configureTestingModule({providers:[{provide:ProductService,useValue:{getProducts:()=>of([product]),getProduct:(id:number)=>{expect(id).toBe(42);return of(product)}}}]});
  const service=TestBed.inject(CatalogService);
  const products=await firstValueFrom(service.getProductsByCategory('cama'));
  expect(products[0].id).toBe(42);expect(products[0].variants).toEqual([]);
  expect((await firstValueFrom(service.getProductBySlug(products[0].slug)))?.id).toBe(42);
  expect(await firstValueFrom(service.getProductBySlug('inexistente'))).toBeNull();
 });

 it('preserves the server ordering for coordinated recommendations', async () => {
  const product = (id: number) => ({ id, name: 'Produto ' + id, status: 'active' }) as Parameters<CatalogService['adapt']>[0];
  const getRelatedProducts = jasmine.createSpy('getRelatedProducts').and.returnValue(of([product(9), product(2)]));
  TestBed.configureTestingModule({ providers: [{ provide: ProductService, useValue: { getRelatedProducts } }] });
  const service = TestBed.inject(CatalogService);
  const products = await firstValueFrom(service.getRecommendations(service.adapt(product(1))));
  expect(getRelatedProducts).toHaveBeenCalledOnceWith(1);
  expect(products.map(item => item.id)).toEqual([9, 2]);
 });
 it('uses the persisted cotton title while retaining its original product link', () => {
  TestBed.configureTestingModule({providers: [{provide: ProductService, useValue: {}}]});
  const service = TestBed.inject(CatalogService);
  const source = {
   id: 5, name: 'Jogo de Cama Aurora Floral Vinho 100% Algodão', price: 279.90, quantity: 8, status: 'active', promotional_price: 0,
   category_name: 'Cama / Jogos de cama', measurements: {catalog_slug: 'jogo-de-cama-aurora-floral-vinho-5'},
  } as Parameters<CatalogService['adapt']>[0];
  const item = service.adapt(source);
  expect(item.name).toBe(source.name);
  expect(item.slug).toBe('jogo-de-cama-aurora-floral-vinho-5');
 });
 it('shows a stored 200 Fios title and keeps cotton specifications and the legacy slug', () => {
  TestBed.configureTestingModule({providers: [{provide: ProductService, useValue: {}}]});
  const service = TestBed.inject(CatalogService);
  const source = {
   id: 78, name: 'Edredom Essência Floral Verde Oliva 200 Fios',
   price: 289.90, quantity: 8, status: 'active', promotional_price: 0,
   category_name: 'Cama / Edredons',
   measurements: {
    catalog_slug: 'edredom-essencia-floral-verde-oliva-78',
    'Tecido externo': 'Percal de algodão — 100% algodão — 200 fios',
    'Contagem de fios': '200 fios',
   },
  } as Parameters<CatalogService['adapt']>[0];
  const item = service.adapt(source);
  expect(item.name).toBe(source.name);
  expect(item.slug).toBe(source.measurements!['catalog_slug']);
  expect(item.measurements?.['Contagem de fios']).toBe('200 fios');
  expect(item.measurements?.['Tecido externo']).toContain('100% algodão');
 });
 it('preserves full decoration products inside image frames', () => {
  TestBed.configureTestingModule({providers:[{provide:ProductService,useValue:{}}]});
  const service=TestBed.inject(CatalogService);
  const p=service.adapt({id:42,name:'Cortina',category_name:'Decoração',image_paths:['uploads/curtain.webp']} as Parameters<CatalogService['adapt']>[0]);
  expect(p.images[0].fit).toBe('contain');
  expect(p.images[0].url).toBe('http://localhost:8080/uploads/curtain.webp');
 });

 it('adds an optional wide card rendition while retaining all original gallery URLs',()=>{
  TestBed.configureTestingModule({providers:[{provide:ProductService,useValue:{}}]});
  const service=TestBed.inject(CatalogService);
  const p=service.adapt({id:136,name:'Tapete',category_name:'Decoração',image_paths:['uploads/decoracao-tapete-046-canelado-creme-capa.webp','uploads/ambientacao.webp']} as Parameters<CatalogService['adapt']>[0]);
  expect(p.images[0].url).toBe('http://localhost:8080/uploads/decoracao-tapete-046-canelado-creme-capa.webp');
  expect(p.images[0].cardUrl).toBe('http://localhost:8080/uploads/decoracao-tapete-046-canelado-creme-capa-card.webp');
  expect(p.images[1].cardUrl).toBeUndefined();
 });

});
